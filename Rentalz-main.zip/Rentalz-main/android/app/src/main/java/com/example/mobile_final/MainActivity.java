package com.example.mobile_final;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
