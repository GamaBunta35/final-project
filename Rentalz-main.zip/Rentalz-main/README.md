# mobile_final

Rental Apartments Finder

## Install flutter

This project is a starting point for a Flutter application.
- Install flutter in here: https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_2.5.3-stable.zip
- Extract file in foler: C:\Users\<your-user-name>\Documents
- Open cmd and run: flutter doctor
- flutter doctor --android-licenses
## Open project
- Extract file zip and open RentalZ-main is flutter project
- Open cmd and run: flutter pub get
- Run project with comman: flutter run

## Install Native app
- Install Android studio is here: https://redirector.gvt1.com/edgedl/android/studio/install/2020.3.1.25/android-studio-2020.3.1.25-windows.exe
- Extract folder mobile-java-main and open with Android studio
- Click button run in android studio
